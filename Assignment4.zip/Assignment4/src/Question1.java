import java.util.*;

class Book{
    private String title;
    private int ISBN;
    private int Barcode;
    public Book(String title, int ISBN, int barcode) {
        this.title = title;
        this.ISBN = ISBN;
        Barcode = barcode;
    }
    public String gettitle() {
        return title;
    }
    public int getISBN() {
        return ISBN;
    }
    public int getBarcode() {
        return Barcode;
    }

    @Override
    public String toString() {//idhar object class ka to string function ko ovveride kara gaya hai apne suwaad anusaar
        return "Book{" +
                "title='" + title + '\'' +
                ", ISBN=" + ISBN +
                ", Barcode=" + Barcode +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Book book = (Book) o;
        return ISBN == book.ISBN && Barcode == book.Barcode && Objects.equals(title, book.title);
    }
}
class BookComparator implements Comparator<Book> {
    @Override
    public int compare(Book a, Book b) {
        if(a.gettitle().compareToIgnoreCase(b.gettitle())!=0){
             return a.gettitle().compareToIgnoreCase(b.gettitle());
        }
        else if(a.getISBN()!=b.getISBN()){
            return a.getISBN()- b.getISBN();
        }
        else{
            return a.getBarcode()-a.getBarcode();
        }
    }
}
public class Question1 {
    public static void main(String[] args) {
          Scanner sc = new Scanner(System.in);
//        System.out.println("Enter the number of books: ");
        int N = 15;
//        System.out.println("Enter the numbers of racks: ");
        int K = 3;
        int slots = N/K;
        Book books[] = new Book[N];
        //YAHAN MENE bill create kara hai
        books[0]=new Book("HCV",1234,1000);
        books[1]=new Book("PHYSICS",2345,1001);
        books[2]=new Book("MATHS",1154,1002);
        books[3]=new Book("MATHS",1241,1003);
        books[4]=new Book("HCV",1234,1004);
        books[5]=new Book("CHEMISTRY",1224,1005);
        books[6]=new Book("OPERATING",1214,1006);
        books[7]=new Book("SYSTEM",1145,1007);
        books[8]=new Book("COMPUTER",1124,1008);
        books[9]=new Book("CODING",1034,1009);
        books[10]=new Book("CODING",11034,1010);
        books[11]=new Book("SCIENCE",1239,1011);
        books[12]=new Book("SST",1909,1012);
        books[13]=new Book("GARDA",1994,1013);
        books[14]=new Book("GARDA",1994,1014);



//        sc.nextLine();
//        for(int i = 0;i<N;i++){
//            System.out.println("Enter the title: ");
//            String title = sc.nextLine();
//            System.out.println("Enter the ISBN: ");
//            int ISBN = sc.nextInt();
//            System.out.println("Enter the Barcode: ");
//            int Barcode = sc.nextInt();
//            sc.nextLine();
//            Book b = new Book(title,ISBN,Barcode);
//            books[i]=b;
//        }

//        for(int i = 0;i<N;i++){
//            System.out.println( Books.get(i));
//        }
        System.out.println("The list of of book you have to put in your library book Shell: ");
        for(int i = 0;i<N;i++){
            System.out.println(books[i]);
        }
        List Books = Arrays.asList(books);// yahan hamne list me change kiya hai array ko
        Collections.sort(Books,new BookComparator());//Sorting of books

       System.out.println("Enter the books detail of which you wants find the position in racks :");
//        for(int i = 0;i<N;i++){
              System.out.println("Enter the title: ");
            String title = sc.nextLine();
            System.out.println("Enter the ISBN: ");
            int ISBN = sc.nextInt();
            System.out.println("Enter the Barcode: ");
            int Barcode = sc.nextInt();
            sc.nextLine();
            Book b = new Book(title,ISBN,Barcode);
            for(int j = 0;j<N;j++){
               if(Books.get(j).equals(b)) {
                   int racks  = j/slots +1;
                   int slot_number = j-(racks-1)*slots+1;
                   System.out.println("This book should be placed at rack number "+racks+" and slot number "+slot_number);

               }
               else{
                   System.out.println("This book is not present in our bill .");
               }
            }
//        }




    }

}
