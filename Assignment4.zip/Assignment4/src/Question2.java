import java.util.ArrayList;
import java.util.Scanner;
class ColorPixel{
    private int rValue;
    private int gValue ;
    private int bValue ;

    public ColorPixel(int a) {
        if (a == 0) {
            this.bValue = a;
            this.gValue = a;
            this.rValue = a;
        } else {
            Scanner sc = new Scanner(System.in);
            System.out.println("Enter the value of Red: ");
            this.rValue = sc.nextInt();
            System.out.println("Enter the value of Green : ");
            this.gValue = sc.nextInt();
            System.out.println("Enter the value of Blue: ");
            this.bValue = sc.nextInt();
        }
    }

    public int getrValue() {
        return rValue;
    }
    public int getgValue() {
        return gValue;
    }
    public int getbValue() {
        return bValue;
    }

}
class GrayPixel{
    private int g_value ;
    public GrayPixel(int a) {
        if(a==0){
            this.g_value=a;
        }
        else{
            System.out.println("Enter the value of pixel");
        Scanner sc = new Scanner(System.in);
        this.g_value = sc.nextInt();}

    }
    public int getG_value() {
        return g_value;
    }
}
class ColorImage{
    private int no_of_row;
    private int no_of_column;
    public ColorImage(int a){
        input(a);
    }
    ArrayList<ArrayList<ColorPixel>> Image = new ArrayList<>();
    void input(int a) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter the number of row: ");
        int r = sc.nextInt();
        System.out.println("Enter the number of column: ");
        int c = sc.nextInt();
        for (int i = 0; i < r; i++) {
            ArrayList<ColorPixel> row = new ArrayList<>();
            for (int j = 0; j < c; j++) {
                ColorPixel pixels = new ColorPixel(a);
                row.add(pixels);
            }
            Image.add(row);
            this.no_of_column = row.size();
        }
        this.no_of_row= Image.size();

    }
    void display(int a){
        System.out.println("RED Pixels");
        for(int i = 0;i<Image.size();i++){
            for(int j = 0;j<no_of_column;j++){
                System.out.print(Image.get(i).get(j).getrValue()-a+" ");
            }
            System.out.println();
        }
        System.out.println("BLUE Pixels");
        for(int i = 0;i<Image.size();i++){
            for(int j = 0;j<no_of_column;j++){
                System.out.print(Image.get(i).get(j).getbValue()-a+" ");
            }
            System.out.println();
        }
        System.out.println("GREEN Pixels");
        for(int i = 0;i<Image.size();i++){
            for(int j = 0;j<no_of_column;j++){
                System.out.print(Image.get(i).get(j).getrValue()-a+" ");
            }
            System.out.println();
        }
    }
    void update(){
        Image.clear();
        input(1);
    }
    void DisplayNegative(){
        display(255);

    }
}
class GrayImage{
    private int no_of_row;
    private int no_of_column;
    public GrayImage(int a){
        input(a);
    }
    ArrayList<ArrayList<GrayPixel>> Image = new ArrayList<>();
    void input(int a) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter the number of row: ");
        int r = sc.nextInt();
        System.out.println("Enter the number of column: ");
        int c = sc.nextInt();
        for (int i = 0; i < r; i++) {//
            ArrayList<GrayPixel> row = new ArrayList<>();
            for (int j = 0; j < c; j++) {//
                GrayPixel pixels = new GrayPixel(a);
                row.add(pixels);
            }
            Image.add(row);
            this.no_of_column = row.size();
        }
        this.no_of_row= Image.size();

    }
    void display(int a){
        System.out.println("GRAY Pixels");
        for(int i = 0;i<Image.size();i++){
            for(int j = 0;j<no_of_column;j++){
                System.out.print(Image.get(i).get(j).getG_value()-a+" ");
            }
            System.out.println();
        }
    }
    void update(){
        Image.clear();
        input(1);
    }
    void DisplayNegative(){
        display(255);
    }
}
public class Question2 {
    public static void main(String[] args) {
        boolean f = true;
        boolean g = true;
        boolean fl = true;
        boolean flg = true;
        boolean flag = true;
        while (flag) {
            System.out.println("Operations with an Image " + "\n" + "1. Genrate an Image" + "\n" + "2. Input an image" + "\n" + "3. Exist");
            Scanner sc = new Scanner(System.in);

            int opt = sc.nextInt();

            switch (opt) {
                case 1:
                    System.out.println("1. Color" + "\n" + "2. Gray");
                    int op = sc.nextInt();
                    switch (op) {
                        case 1:
                            ColorImage ci = new ColorImage(0);
                            while (flg) {
                                System.out.println("1. Display" + "\n" + "2. Update" + "\n" + "3. Negative" + "\n" + "4. Exit");
                                int p = sc.nextInt();
                                switch (p) {
                                    case 1:
                                        ci.display(0);
                                        break;
                                    case 2:
                                        ci.update();
                                        break;
                                    case 3:
                                        ci.DisplayNegative();
                                    case 4:
                                        flg = false;
                                        break;
                                }
                            }
                            break;
                        case 2:
                            GrayImage gi = new GrayImage(0);
                            while (g) {
                                System.out.println("1. Display" + "\n" + "2. Update" + "\n" + "3. Negative" + "\n" + "4. Exit");
                                int pi = sc.nextInt();
                                switch (pi) {
                                    case 1:
                                        gi.display(0);
                                        break;

                                    case 2:
                                        gi.update();
                                        break;
                                    case 3:
                                        gi.DisplayNegative();
                                        break;
                                    case 4:
                                        g = false;
                                        break;

                                }

                            }
                            break;
                    }
                case 2:
                     System.out.println("1. Color" + "\n" + "2. Gray");
                     int optt = sc.nextInt();
                     switch (optt) {
                         case 1:
                           ColorImage CI = new ColorImage(1);
                           while (fl) {
                               System.out.println("1. Display" + "\n" + "2. Update" + "\n" + "3. Negative" + "\n" + "4. Exit");
                               int p = sc.nextInt();
                               switch (p) {
                                     case 1:
                                         CI.display(0);
                                         break;
                                     case 2:
                                          CI.update();
                                          break;
                                        case 3:
                                          CI.DisplayNegative();
                                        case 4:
                                          fl = false;
                                          break;
                                        }
                                    }
                                    break;
                         case 2:
                              GrayImage gI = new GrayImage(1);

                              while (f) {
                                  System.out.println("1. Display" + "\n" + "2. Update" + "\n" + "3. Negative");
                                  int pi = sc.nextInt();
                                  switch (pi) {
                                      case 1:
                                          gI.display(0);
                                          break;
                                      case 2:
                                          gI.update();
                                          break;
                                      case 3:
                                          gI.DisplayNegative();
                                      case 4:
                                          flg = false;
                                          break;
                                  }
                              }
                            }
                            break;
                        case 3:
                            flag = false;
                            break;
                    }

            }

        }
    }
