import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;
public class Slides{
    String slideName;
    String [] content;
    String uploadby;
    Date date;
    SimpleDateFormat ft = new SimpleDateFormat ("E M dd  HH:mm:ss 'IST' yyyy");

    public Slides(String uploadby) {
        this.uploadby = uploadby;
        this.date = new Date();
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter topic of slides: ");
        slideName = sc.nextLine();
        System.out.print("Enter number of slides: ");
        int numberOfSlides = sc.nextInt();
        sc.nextLine();
        System.out.println("Enter content of slides");
        content = new String[numberOfSlides];
        for(int i = 0;i<numberOfSlides;i++){
            System.out.print("Content of slide "+ (i+1)+" ");
            content[i]= sc.nextLine();
        }
    }
    public void PrintSlides(){
        System.out.println("Title: "+slideName);
        for(int i = 0;i<content.length;i++){
            System.out.println("Slide: "+(i+1)+" "+content[i]);
        }
        System.out.println("Date of upload: "+ft.format(date));
        System.out.println("Uploaded by: "+uploadby);
        System.out.println("------------------------------------");
    }


}