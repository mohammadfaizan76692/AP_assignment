import java.text.SimpleDateFormat;
import java.util.Date;

public class Lecture {
    String topic;
    String fileName;
    Date date;
    String uploadedBy;
    SimpleDateFormat ft = new SimpleDateFormat ("E M dd  HH:mm:ss 'IST' yyyy");
    public Lecture(String topic, String fileName,String uploadedBy) {
        this.topic = topic;
        this.fileName = fileName;
        this.date = new Date();
        this.uploadedBy = uploadedBy;
    }

    public String getTopic() {
        return topic;
    }

    public void setTopic(String topic) {
        this.topic = topic;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getDate() {
        return ft.format(date);
    }

    public void setDate(Date date) {
        this.date = date;
    }
    public void printLectureDetails(){
        System.out.println("Title of video: "+topic);
        System.out.println("Video file: "+fileName);
        System.out.println("Date of upload: "+ ft.format(date));
        System.out.println("Uploaded by: "+uploadedBy);
        System.out.println("------------------------------------");
    }
}

