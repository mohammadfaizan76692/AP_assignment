import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Assignment implements Assessment {
    public String status;

    private final int ID ;
    private final String name;
    private String uploadby;
    private final int maxMarks;
    Map<String ,StudentData> students;

    public Assignment(String uploadby, ArrayList<String> Student) {
        status = "Open";
        ID = MAIN.index;
        MAIN.index++;

        Scanner sc = new Scanner(System.in);
        System.out.print("Enter problem statement: ");
        name = sc.nextLine();
        System.out.print("Enter max marks: ");
        maxMarks = sc.nextInt();
        this.uploadby = uploadby;
        students = new HashMap<>();
        students = new HashMap<>();
        for(int i= 0;i<Student.size();i++){
            StudentData nayaData = new StudentData();
            students.put(Student.get(i),nayaData);
        }
    }
    @Override
    public int getMarks(String student) {
        return  students.get(student).getMarksGained();
    }

    @Override
    public String getStatus(String student) {
        return students.get(student).getStatus();
    }

    @Override
    public String getSubmission(String student) {
        return students.get(student).getSubmission();
    }

    @Override
    public void printAssessment() {
        System.out.println("ID: " + ID + " Question: " + name + " Max marks: " + maxMarks);
        System.out.println("-----------------");

    }

    @Override
    public void gradeStudents(String instructor_id) {
        for (Map.Entry<String,StudentData> en : students.entrySet()  ) {
            if(en.getValue().getStatus().equals("Submitted")){
                System.out.println(en.getKey());
            }
        }

        Scanner sc = new Scanner(System.in);
        String id = sc.nextLine();
        System.out.println("Submission: " +  students.get(id).getSubmission());
        System.out.println("Max Marks: " + maxMarks);
        System.out.println("Marks Scored: ");
        int score = sc.nextInt();
        students.get(id).setStatus("Graded");
        students.get(id).setGradedBy(instructor_id);
        students.get(id).setMarksGained(score);

    }

    public int getID() {
        return ID;
    }

    @Override
    public void submit(String student_id){
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter filename of Assignment");
        String filename = sc.nextLine();
        if(filename.substring(filename.length() - 4, filename.length()).equals(".zip")){
         students.get(student_id).setStatus("Submitted");
         students.get(student_id).setSubmission(filename);
            System.out.println("Submitted successfully");
        }else {
            System.out.println("File Format not supported");
        }
    }
    void viewGrade(String student_id,boolean Isgraded) {
        if(Isgraded){
            if(students.get(student_id).getStatus().equals("Graded")){
                System.out.println("Submisiion: "+students.get(student_id).getSubmission());
                System.out.println("Max Marks: "+maxMarks);
                System.out.println("Marks scored: "+students.get(student_id).getMarksGained());
                System.out.println("Graded by: "+students.get(student_id).getGradedBy());
            }
        }else{
            if(students.get(student_id).getStatus().equals("Graded") == false){
                System.out.println("Submisiion: "+students.get(student_id).getSubmission());
            }
        }

    }
}
