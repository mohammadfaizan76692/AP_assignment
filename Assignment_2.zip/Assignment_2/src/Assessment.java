interface Assessment {
    int  getMarks(String student );
    String getStatus(String student);
    String  getSubmission(String student);
    void printAssessment();
    void gradeStudents(String instructor_id);
    void submit(String student_id);
}
