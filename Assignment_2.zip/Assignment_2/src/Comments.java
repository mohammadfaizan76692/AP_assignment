import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class Comments {
    String comment;
    String id;
    Date date ;
    SimpleDateFormat ft = new SimpleDateFormat ("E M dd  HH:mm:ss 'IST' yyyy");
    public Comments(String id) {
        this.id = id;
        Scanner sc =new Scanner(System.in);
        System.out.print("Enter comment: ");
        this.comment = sc.nextLine();
        this.date = new Date();
    }
    public void showCommnets(){
        System.out.println(comment+" - "+id+"\n" +ft.format(date));
    }
}
