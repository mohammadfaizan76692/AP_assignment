import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Quiz implements Assessment{
    public String status;
    private String uploadby;
    private int ID;
    private String name;
    Map<String ,StudentData> students;

    public int getID() {
        return ID;
    }

    public String getName() {
        return name;
    }

    public Quiz(String uploadby, ArrayList<String> Student) {
        status = "Open";
        ID = MAIN.index;
        this.uploadby = uploadby;
        MAIN.index++;
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter quiz question: ");
        name = sc.nextLine();
        students = new HashMap<>();
        for(int i= 0;i<Student.size();i++){
            StudentData nayaData = new StudentData();
            students.put(Student.get(i),nayaData);
        }

    }

    @Override
    public int getMarks(String student) {
        return students.get(student).getMarksGained();
    }

    @Override
    public String getStatus(String student) {
        return students.get(student).getStatus();
    }

    @Override
    public String getSubmission(String student) {
        return students.get(student).getSubmission();
    }

    @Override
    public void printAssessment() {
        System.out.println("ID: " + ID + " Question: " + name);
        System.out.println("-----------------");
    }

    @Override
    public void gradeStudents(String instructor_id) {

        System.out.print("Choose ID from these ungraded Submissions: ");
        for (Map.Entry<String,StudentData> en : students.entrySet()  ) {
            if(en.getValue().getStatus().equals("Submitted")){
                System.out.println(en.getKey());
            }
        }

        Scanner sc = new Scanner(System.in);
        String id = sc.nextLine();
        System.out.println("Submission: " +  students.get(id).getSubmission());
        System.out.println("Max Marks: " + 1);
        System.out.println("Marks Scored: ");
        int score = sc.nextInt();
        students.get(id).setStatus("Graded");
        students.get(id).setGradedBy(instructor_id);
        students.get(id).setMarksGained(score);
    }
    @Override
    public void submit(String student_ID){
        Scanner sc = new Scanner(System.in);
        System.out.println(name);
        String answer = sc.nextLine();
        students.get(student_ID).setStatus("Submitted");
        students.get(student_ID).setSubmission(answer);
        System.out.println("submitted successfully");
    }
    void viewGrade(String student_id,boolean Isgraded) {
        if(Isgraded){
            if(students.get(student_id).getStatus().equals("Graded")){
                System.out.println("Submission: "+students.get(student_id).getSubmission());
                System.out.println("Max Marks: 1");
                System.out.println("Marks scored: "+students.get(student_id).getMarksGained());
                System.out.println("Graded by: "+students.get(student_id).getGradedBy());
            }
        }else {
            if(students.get(student_id).getStatus().equals("Graded") == false && students.get(student_id).getStatus().equals("Submitted")){
                System.out.println("Submission: "+students.get(student_id).getSubmission());
            }
        }



    }
}
