public class StudentData {
    String status = "Not Submitted";
    int MarksGained;
    String gradedBy;


    String Submission;

    public String getSubmission() {
        return Submission;
    }

    public void setSubmission(String submission) {
        Submission = submission;
    }

    public int getMarksGained() {
        return MarksGained;
    }

    public String getGradedBy() {
        return gradedBy;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void setMarksGained(int marksGained) {
        MarksGained = marksGained;
    }

    public void setGradedBy(String gradedBy) {
        this.gradedBy = gradedBy;
    }
}
