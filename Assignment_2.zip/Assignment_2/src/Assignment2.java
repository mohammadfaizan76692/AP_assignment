import java.util.ArrayList;
import java.util.Scanner;

public class Assignment2 {
   public  static Scanner sc = new Scanner(System.in);
   public static MAIN cpu = new MAIN();

    public static void main(String[] args) {

        ArrayList<String> students = new ArrayList<>();
        ArrayList<String> instructors = new ArrayList<>();
        students.add("S0");
        students.add("S1");
        students.add("S2");
        instructors.add("I0");
        instructors.add("I1");

        for (String s :
                students) {
            cpu.addStudent(s);
        }




        do {
            System.out.println("Welcome to Backpack\n" +
                    "1. Enter as instructor\n" +
                    "2. Enter as student\n" +
                    "3. Exit");
            int option = sc.nextInt();
            switch (option) {
                case 1:
                    for(int i = 0;i<instructors.size();i++){
                        System.out.println(i +" - "+instructors.get(i));
                    }
                    System.out.print("Choose id: ");
                    int opt = sc.nextInt();
                    asInstructor(instructors.get(opt)); break;
                case 2:
                    for(int i = 0;i<students.size();i++){
                        System.out.println(i +" - "+students.get(i));
                    }
                    System.out.print("Choose id: ");
                    int opt2 = sc.nextInt();
                    asStudent(students.get(opt2)); break;
                case 3:
                    System.exit(0);
            }
        } while (true);
    }

    public static void asInstructor(String id) {
        do{
            System.out.println("Welcome : "+id);
            printInstructorMenu();
            int option = sc.nextInt();
            switch (option){
                case 1:
                    cpu.AddclassMaterial(id);
                    break;
                case 2:
                    cpu.AddAssesment(id);
                    break;
                case 3:
                    cpu.viewMaterial();
                    break;
                case 4:
                    cpu.view_Assessment(true);
                    break;
                case 5:
                    cpu.grade_Assessment(id);
                    break;
                case 6:
                    cpu.closeAssessment();
                    break;
                case 7:
                    cpu.viewComments();
                    break;
                case 8:
                    cpu.addComments(id);
                    break;
                case 9: return;

            }


        }while (true);
    }

    public static void asStudent(String id) {
        do{
            System.out.println("Welcome : "+id);
            printStudentmenu();
            int option = sc.nextInt();
            switch (option){
                case 1:
                    cpu.viewMaterial();
                    break;
                case 2:
                    cpu.view_Assessment(true);
                    break;
                case 3:
                    cpu.submitAssessment(id);
                    break;
                case 4:
                    cpu.viewGrades(id);
                    break;
                case 5:
                    cpu.viewComments();
                    break;
                case 6:
                    cpu.addComments(id);
                    break;
                case 7: return;
            }
        }while (true);
    }
    public static void printInstructorMenu() {
        System.out.println("INSTRUCTOR MENU\n" +
                "1. Add class material\n" +
                "2. Add assessments\n" +
                "3. View lecture materials\n" +
                "4. View assessments\n" +
                "5. Grade assessments\n" +
                "6. Close assessment\n" +
                "7. View comments\n" +
                "8. Add comments\n" +
                "9. Logout");
    }

    public static void printStudentmenu() {
        System.out.println("STUDENT MENU\n" +
                "1. View lecture materials\n" +
                "2. View assessments\n" +
                "3. Submit assessment\n" +
                "4. View grades\n" +
                "5. View comments\n" +
                "6. Add comments\n" +
                "7. Logout");
    }
}
