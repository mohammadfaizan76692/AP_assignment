import java.util.ArrayList;
import java.util.Scanner;

public class MAIN {
    public static int index = 0 ;
    ArrayList<Quiz> quizes = new ArrayList<>();
    ArrayList<Assignment> assignments = new ArrayList<>();
    ArrayList<Slides> slide = new ArrayList<>();
    ArrayList<Lecture> lecture  = new ArrayList<>();
    ArrayList<String> students = new ArrayList<>();
    ArrayList<Comments> comments = new ArrayList<>();
    void AddclassMaterial(String instructorName){
        Scanner sc = new Scanner(System.in);
        System.out.println("1. Add Lecture Slide");
        System.out.println("2. Add Lecture Video");
        int option = sc.nextInt();
        sc.nextLine();
        if(option==1){
            Slides s = new Slides(instructorName);
            slide.add(s);
            System.out.println("Material added");
        }
        else{

            System.out.print("Enter topic of Video: ");
            String topic = sc.nextLine();
            System.out.println("Enter the file name: ");
            String filename = sc.nextLine();
            if(filename.substring(filename.length()-4,filename.length()).equals(".mp4")  )  {
                Lecture l = new Lecture(topic,filename,instructorName);
                lecture.add(l);
                System.out.println("Material added");
            }
            else {
                System.out.println("This Video File format is not Supported ");
            }
        }

    }
    void view_Assessment(boolean isall){
        for(int i = 0;i<quizes.size();i++){
            if(isall){
                quizes.get(i).printAssessment();
            }
            else{
                if(quizes.get(i).status.equals("Open")){
                    quizes.get(i).printAssessment();
                }
            }

        }
        for(int i = 0;i<assignments.size();i++){
            if(isall){
                assignments.get(i).printAssessment();
            }
            else{
                if(assignments.get(i).status.equals("Open")){
                    assignments.get(i).printAssessment();
                }
            }
        }
    }
    public void AddAssesment(String id){
        Scanner sc = new Scanner(System.in);
        System.out.println("1. Add Assignment");
        System.out.println("2. Add Quiz");
        int option = sc.nextInt();
        if(option==1){
            Assignment assign = new Assignment(id, students);
            assignments.add(assign);

        }
        else{
            Quiz quiz  = new Quiz(id, students);
            quizes.add(quiz);
        }
    }
    public void submitAssessment(String Student_id){
        boolean pending = false;
        for(int i = 0;i<assignments.size();i++){
            if(assignments.get(i).getStatus(Student_id).equals("Not Submitted") && assignments.get(i).status.equals("Open")){
                if(pending==false){
                    System.out.println("Pending Assessments");
                    pending =true;
                }
                assignments.get(i).printAssessment();
            }
        }
        for(int i = 0;i<quizes.size();i++){
            if(quizes.get(i).getStatus(Student_id).equals("Not Submitted")  && quizes.get(i).status.equals("Open")){
                if(pending==false){
                    System.out.println("Pending Assessments");
                    pending =true;
                }
                quizes.get(i).printAssessment();
            }
        }
        if(pending==false){
            System.out.println("No pending assessments");
        }
        else{
            Scanner sc = new Scanner(System.in);
            System.out.print("Enter Id of Assessment: ");
            int id = sc.nextInt();
            for(int i=0;i<quizes.size();i++){
                if(id==quizes.get(i).getID()){
                    quizes.get(i).submit(Student_id);
                    break;
                }
            }
            for(int i=0;i<assignments.size();i++) {
                if (id == assignments.get(i).getID()) {
                    assignments.get(i).submit(Student_id);
                    break;
                }
            }

        }
    }


    void grade_Assessment(String instructor_id){
        Scanner sc = new Scanner(System.in);
        view_Assessment(false);
        System.out.println("List of assessments");
        System.out.print("Enter Id of Assessment to view Submission: ");
        int id = sc.nextInt();
        System.out.println("Choose ID from these ungraded submissions ");
        for(int i=0;i<quizes.size();i++){
            if(id==quizes.get(i).getID()){
                quizes.get(i).gradeStudents(instructor_id);
                break;
            }
        }
        for(int i=0;i<assignments.size();i++){
            if(id==assignments.get(i).getID()){
                assignments.get(i).gradeStudents(instructor_id);
                break;
            }
        }
    }

    void viewMaterial() {
        if(lecture.size() == 0 && slide.size() == 0) {
            System.out.println("No material found");
            return;
        }
        for (Lecture l:
              lecture) {
            l.printLectureDetails();
        }
        for(Slides s : slide) {
            s.PrintSlides();
        }
    }


    private void viewGradedSubmission(String student_id){
        System.out.println("Graded submissions: ");
        for(int i = 0;i<quizes.size();i++){
            quizes.get(i).viewGrade(student_id,true);
        }
        for(int i = 0;i<assignments.size();i++){
            assignments.get(i).viewGrade(student_id,true);
        }
    }
    private void viewUnGradedSubmission(String student_id){
        System.out.println("Ungraded submissions: ");
        for(int i = 0;i<quizes.size();i++){
            quizes.get(i).viewGrade(student_id,false);
        }
        for(int i = 0;i<assignments.size();i++){
            assignments.get(i).viewGrade(student_id,false);
        }
    }

    public void viewGrades(String student_id) {
        viewGradedSubmission(student_id);
        viewUnGradedSubmission(student_id);
    }

    void addStudent(String student_id){
        students.add(student_id);
    }
    private void printOpenAssessments(){
        for(int i = 0;i<assignments.size();i++){
            if(assignments.get(i).status.equals("Open")){
                assignments.get(i).printAssessment();

            }
        }
        for(int i = 0;i<quizes.size();i++){
            if(quizes.get(i).status.equals("Open")){
                quizes.get(i).printAssessment();
            }
        }
    }

    void closeAssessment(){
        System.out.println("List of Open Assignments:");
        printOpenAssessments();
        System.out.print("Enter id of assignment to close: ");
        Scanner sc = new Scanner(System.in);
        int idclose = sc.nextInt();
        for(int i = 0;i<quizes.size();i++){
            if(idclose==quizes.get(i).getID()){
                quizes.get(i).status="Close";
                break;
            }
        }
        for(int i = 0;i<assignments.size();i++){
            if(idclose==assignments.get(i).getID()){
                assignments.get(i).status="Close";
                break;
            }
        }

        System.out.println("Assessment successfully closed");
    }
    public void addComments(String id){
        Comments c = new Comments(id);
        comments.add(c);

    }
    public void viewComments(){
        for(int i =0;i<comments.size();i++){
            comments.get(i).showCommnets();
        }
    }


}
